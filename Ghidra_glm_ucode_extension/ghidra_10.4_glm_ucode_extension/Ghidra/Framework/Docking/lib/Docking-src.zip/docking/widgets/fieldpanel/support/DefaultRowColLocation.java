/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package docking.widgets.fieldpanel.support;

/**
 * A location used to represent a an edge case where not suitable location can be found and the
 * client does not wish to return null.
 */
public class DefaultRowColLocation extends RowColLocation {
	public DefaultRowColLocation() {
		super(0, 0);
	}

	public DefaultRowColLocation(int row, int col) {
		super(row, col);
	}

	@Override
	public RowColLocation withCol(int newColumn) {
		return new DefaultRowColLocation(row, newColumn);
	}

	@Override
	public RowColLocation withRow(int newRow) {
		return new DefaultRowColLocation(newRow, col);
	}

}
